var jwt = require('jsonwebtoken');

exports.handler = async (event) => {
    console.log('event', event);
    
    // TODO implement
    const response = {
        statusCode: 200,
        body: JSON.stringify('Hello from Lambda!'),
    };
    return response;
};
